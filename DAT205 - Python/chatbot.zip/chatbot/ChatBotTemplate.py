#Import Libraries 
import random
import urllib2

#Store stop-words
file = open("stop-words.txt")
stopwords = file.readlines()

#Choose a random greeting from array
greet = ['Hey ', 'Hello ', 'Hi ', 'Hola ', 'Howdy ']
randomGreet = random.choice(greet)

#Happy mood array
happyLines = ['That is good to hear ', 'I am glad ', 'Good to hear! ', 'I happy for you ', 'Me too! ']
randomHappy = random.choice(happyLines)
#Sad mood array
sadLines = ['I feel sorry for you ', 'Thats bad! ']
randomSad = random.choice(sadLines)

def removeStopwords (filterNames): 
    for word in stopwords:
        next = word.lower().strip()
        filterNames = filterNames.replace(" " + next + " ", " ").lower() 
    return filterNames   

#Attempt to determine the users mood and apply correct responce 
def mood ():
    input = raw_input("How're you feeling, " + name + "? ")
    
    filerwords = removeStopwords(input).lower
    
    if filerwords == 'happy':
        print randomHappy + name
         
    elif filerwords == 'great':
        print randomHappy + name
        
    elif filerwords == 'amazing':
        print randomHappy + name
        
    elif filerwords == 'ok':
        print randomHappy + name
        
    elif filerwords == 'good':
        print randomHappy + name
        
    elif filerwords == 'bad':
        print randomSad + name
        
#Do a wiki search on a certain word. Attepted.     
def wiki (inputWord):
    #Open and store Wikipedia
    openURL = rllib2.urlopen("http://en.wikipedia.org/wiki/"+inputWord)
    readPage = openURL.read()
    
    #Find the <p> tags
    findTheP = readPage.find("<p>")
    findTheEndP = readPage.find("</p>", findTheP)
    
    page = readPage[findTheP:findTheEndP]
    return page

#First question - name
input = raw_input(randomGreet + " I'm a chatbot, what's your name? ")  
filerwords = removeStopwords(input)

#Remove "my"
name = filerwords.replace("my ", " ")

#Greet the user
print randomGreet + name + ", nice to meet you!" 

#Second question - feelings
mood()

#Third question - wikipedia
input = raw_input("What would you like to know? ")
wiki(input)
print ("I found this on: " + page)


